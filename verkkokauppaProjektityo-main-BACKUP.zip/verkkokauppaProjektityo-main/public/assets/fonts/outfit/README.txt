Hei!

Nimeni on Justus Putkonen ja olen 17-vuotias, innokas ohjelmistokehittäjä toiselta vuodelta Savon ammattiopistosta. Harrastan sulkapalloa ja käyn aktiivisesti kuntosalilla. Kuulin yrityksestänne opettajaltani ja se herätti kiinnostukseni. Olisiko teillä mahdollisesti tarvetta ahkeralle työharjoittelijalle? Harjoitteluni ajankohta on 7.1-20.3. Harjoittelun pystyy suorittamaan etänä tai työpaikalta käsin.

Olen harjoitellut jonkin verran WordPressillä tuottamista ja opin kokoajan uutta!  Osaan käyttää seuraavia ohjelmointi kieliä: HTML, PHP, SQL, CSS ja JavaScript. Olen myös todella nopea oppimaan, jos opitut asiat eivät odota vaatimuksianne, voin myös tarvittaessa opetella ennen työharjoittelua lisää.

Yhteistiedot:
GitHub: https://github.com/Justus45
Puhelinnumero: 0456145772

Toivottavasti kuulen teistä lisää!
Ystävällisin terveisin: Justus Putkonen
