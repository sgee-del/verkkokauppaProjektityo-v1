<header class="row space-between top-nav">
    <div class="row nav-align">
        <a href="index.php" class="nav-link"><h1>Ruoka</h1></a>
        <a href="items.php" class="nav-link">Tuotteet</a>
    </div>
    <div class="row nav-align">
        <a href="#" class="nav-link"><img src="assets/images/nav-search.svg" class="nav-icon"></a>
        <a href="register.php" class="nav-link"><img src="assets/images/nav-adduser.svg" class="nav-icon"></a>
        <a href="login.php" class="nav-link"><img src="assets/images/nav-login.svg" class="nav-icon"></a>
        <a href="cart.php" class="nav-link link-shopping-cart"><img src="assets/images/nav-shoppingcart.svg" class="nav-icon"></a>
    </div>
</header>