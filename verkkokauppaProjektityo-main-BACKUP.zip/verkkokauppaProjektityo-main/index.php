<!-- Ohjaa käyttäjän frontend/index.php sivulle -->
<?php
header('Location: public/index.php');
exit;